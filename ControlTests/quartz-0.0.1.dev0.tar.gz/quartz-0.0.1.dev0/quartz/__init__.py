
__version__ = "0.0.1dev"
__author__ = "Vlad Calin"
__email__ = "vlad.s.calin@gmail.com"